create procedure insertrecord(IN id int(10), IN name varchar(50), IN dept_name varchar(50), IN score decimal)
  BEGIN
	insert into student values(id, name, dept_name, score);
END;

